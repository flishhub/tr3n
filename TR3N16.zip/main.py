# main.py – TR3N v1.6 (classic grid + menu + audio + scoreboard + Flynn Lives)

import pygame
import os
import time
from Player import Player
from Menu import Menu

# Initialize pygame and mixer
pygame.init()
pygame.mixer.init()
pygame.font.init()
pygame.display.set_caption("TR3N Light Cycle – v1.6")

# Load and play greeting
def play_greeting():
    greeting_path = os.path.join("assets", "audio", "greetings_programs.wav")
    if os.path.exists(greeting_path):
        sound = pygame.mixer.Sound(greeting_path)
        sound.set_volume(1.0)
        sound.play()
        time.sleep(2)
    else:
        print("Audio file not found:", greeting_path)

# Flynn Lives terminal overlay
def launch_terminal(screen):
    font = pygame.font.SysFont("Courier New", 24)
    messages = [
        "Initializing ENCOM secure shell...",
        "Connecting to Grid node: TR3N-CORE...",
        "Alan Bradley: \"The Grid is real. Flynn was right.\"",
        "Signal detected: ARES protocol inbound...",
        "Flynn Lives."
    ]
    screen.fill((0, 0, 0))
    for i, msg in enumerate(messages):
        text = font.render(msg, True, (0, 255, 0))
        screen.blit(text, (50, 100 + i * 40))
        pygame.display.flip()
        time.sleep(1.5)
    time.sleep(2)

# Setup screen and clock
screen = pygame.display.set_mode((1024, 768))
clock = pygame.time.Clock()
font = pygame.font.SysFont("Arial", 36)

# Play greeting once
play_greeting()

# Menu loop
menu = Menu(screen)
in_menu = True
best_of_3 = False

while in_menu:
    menu.draw()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
        action = menu.handle_input(event)
        if action == "Start Game":
            in_menu = False
        elif action == "Best of 3":
            best_of_3 = True
            in_menu = False
        elif action == "Flynn Lives":
            launch_terminal(screen)
        elif action == "Quit":
            pygame.quit()
            exit()

# Match setup
player1_score = 0
player2_score = 0
rounds_to_win = 2 if best_of_3 else 1

while player1_score < rounds_to_win and player2_score < rounds_to_win:
    controls_p1 = {'up': pygame.K_w, 'down': pygame.K_s, 'left': pygame.K_a, 'right': pygame.K_d}
    controls_p2 = {'up': pygame.K_UP, 'down': pygame.K_DOWN, 'left': pygame.K_LEFT, 'right': pygame.K_RIGHT}
    player1 = Player(100, 300, (0, 255, 255), controls_p1)
    player2 = Player(700, 300, (255, 100, 0), controls_p2)

    running = True
    while running:
        screen.fill((0, 0, 0))
        keys = pygame.key.get_pressed()

        score_text = f"Player 1: {player1_score}   Player 2: {player2_score}"
        score_surface = font.render(score_text, True, (255, 255, 255))
        screen.blit(score_surface, (screen.get_width() // 2 - score_surface.get_width() // 2, 20))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()

        player1.handle_input(keys)
        player2.handle_input(keys)

        player1.move()
        player2.move()

        player1.check_collision(player2.trail)
        player2.check_collision(player1.trail)

        player1.draw(screen)
        player2.draw(screen)

        if not player1.alive or not player2.alive:
            if player1.alive:
                player1_score += 1
                winner_text = "Player 1 Wins!"
            elif player2.alive:
                player2_score += 1
                winner_text = "Player 2 Wins!"
            else:
                winner_text = "Draw!"

            winner_surface = font.render(winner_text, True, (255, 255, 0))
            screen.blit(winner_surface, (screen.get_width() // 2 - winner_surface.get_width() // 2, 100))
            pygame.display.flip()
            time.sleep(2)
            running = False

        pygame.display.flip()
        clock.tick(15)

# Final winner display
final_winner = "Player 1 Wins the Match!" if player1_score > player2_score else "Player 2 Wins the Match!"
screen.fill((0, 0, 0))
final_surface = font.render(final_winner, True, (0, 255, 0))
screen.blit(final_surface, (screen.get_width() // 2 - final_surface.get_width() // 2, screen.get_height() // 2))
pygame.display.flip()
time.sleep(3)

pygame.quit()