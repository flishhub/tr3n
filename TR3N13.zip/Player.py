# player.py
import pygame

class Player:
    def __init__(self, x, y, color, controls):
        self.x = x
        self.y = y
        self.color = color
        self.controls = controls
        self.direction = 'RIGHT'
        self.trail = [(x, y)]
        self.alive = True

    def handle_input(self, keys):
        if keys[self.controls['up']]:
            self.direction = 'UP'
        elif keys[self.controls['down']]:
            self.direction = 'DOWN'
        elif keys[self.controls['left']]:
            self.direction = 'LEFT'
        elif keys[self.controls['right']]:
            self.direction = 'RIGHT'

    def move(self):
        if not self.alive:
            return

        dx, dy = 0, 0
        if self.direction == 'UP':
            dy = -10
        elif self.direction == 'DOWN':
            dy = 10
        elif self.direction == 'LEFT':
            dx = -10
        elif self.direction == 'RIGHT':
            dx = 10

        new_x = self.x + dx
        new_y = self.y + dy

        # Boundary check (assuming 800x600 screen)
        if 0 <= new_x < 800 and 0 <= new_y < 600:
            self.x = new_x
            self.y = new_y
            self.trail.append((self.x, self.y))
        else:
            self.alive = False  # Crash if out of bounds

    def draw(self, screen):
        for segment in self.trail:
            pygame.draw.rect(screen, self.color, (*segment, 10, 10))

    def check_collision(self, other_trails):
        if (self.x, self.y) in other_trails:
            self.alive = False
