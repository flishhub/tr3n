# tr3n13.py - Main Game loop for TR3N v1.3

import pygame
from Player import Player
from Menu import Menu

pygame.init()
screen = pygame.display.set_mode((800, 600))
clock = pygame.time.Clock()

menu = Menu(screen)
in_menu = True

while in_menu:
    menu.draw()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
        action = menu.handle_input(event)
        if action == "Start Game":
            in_menu = False
        elif action == "Quit":
            pygame.quit()
            exit()

# Define controls
controls_p1 = {'up': pygame.K_w, 'down': pygame.K_s, 'left': pygame.K_a, 'right': pygame.K_d}
controls_p2 = {'up': pygame.K_UP, 'down': pygame.K_DOWN, 'left': pygame.K_LEFT, 'right': pygame.K_RIGHT}

# Create players
player1 = Player(100, 300, (0, 255, 255), controls_p1)
player2 = Player(700, 300, (255, 100, 0), controls_p2)

# Game loop
running = True
while running:
    screen.fill((0, 0, 0))
    keys = pygame.key.get_pressed()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    player1.handle_input(keys)
    player2.handle_input(keys)

    player1.move()
    player2.move()

    player1.check_collision(player2.trail)
    player2.check_collision(player1.trail)

    player1.draw(screen)
    player2.draw(screen)

    if not player1.alive or not player2.alive:
        font = pygame.font.SysFont(None, 48)
        text = font.render("Game Over", True, (255, 0, 0))
        screen.blit(text, (300, 250))
        pygame.display.flip()
        pygame.time.wait(2000)
        running = False

    pygame.display.flip()
    clock.tick(15)

pygame.quit()